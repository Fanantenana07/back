const Router = require("express").Router();
const authentification = require("../auth/authentification");
const mongoose = require("mongoose");
const Course = require("../model/CourseModel");
const Location = require("../model/LocationModel");
const authorization = require("../auth/authorization");
const Users = require("../model/UserModel");
//commande d'un itineraire
Router.post("/commande", [authentification], async (req, res) => {
  const { price, starting, arrive, date, distance } = req.body;
  const { user } = req;
  const course = new Course({
    client: user,
    starting,
    arrive,
    price,
    date,
    distance,
  });
  await course.save();
  res.status(200).send("Votre requete a bien ete recue");
  return;
});

//lists des courses en validation
Router.get("/list", [authentification], async (req, res) => {
  const { user } = req;
  const course = await Course.find({ client: user._id }).populate(
    "client location"
  );
  !course
    ? res.status(204).send("Vous n'avez pas encore de course")
    : res.status(200).send(course);
  return;
});
//toutes les listes des courses
Router.get("/listAll", [authentification, authorization], async (req, res) => {
  const { user } = req;
  const course = await Course.find().populate([
    {
      path: "client",
    },
    {
      path: "location",
      populate: { path: "driver" },
    },
  ]);

  console.log(course);
  !course
    ? res.status(204).send("Vous n'avez pas encore de course")
    : res.status(200).send(course);
  return;
});

Router.put(
  "/finish/:id",
  [authentification, authorization],
  async (req, res) => {
    const { id } = req.params;
    const { location } = req.body;
    console.log(location);
    const course = await Course.findOne({ status: "Valider", _id: id });
    if (!course) return res.status(204).send("Course indisponible");
    const response = await Location.findOne({ _id: location.location._id });
    console.log(response);
    const user = await Users.findOne({ _id: response.driver._id.toString() });
    await user.updateOne({
      $set: {
        status: "Disponible",
      },
    });
    if (!response) return res.status(400).send("Location non trouver");
    await response.updateOne({
      $set: {
        isDisponible: true,
      },
    });
    await course.updateOne({
      $set: {
        status: "Terminer",
      },
    });
    return;
  }
);

Router.delete("/delete/:id", [authentification], async (req, res) => {
  const { id } = req.params;
  const course = await Course.findOne({ _id: id });
  if (!course) res.status(400).send("Course non trouver");
  await course.deleteOne();
  res.status(200).send("suppression terminer");
  return;
});

//toutes les listes des courses d'un chauffeur
Router.get("/driver/list", [authentification], async (req, res) => {
  const { user } = req;
  const course = await Course.find({ driver: user._id }).populate(
    "client location"
  );
  course.forEach((element) => {
    console.log(element.driver);
  });
  course.length < 0
    ? res.send("Vous n'avez pas encore de course")
    : res.status(200).send(course);
  return;
});

//assigner une voiture louer a une course
Router.put(
  "/assing/:id",
  [authentification, authorization],
  async (req, res) => {
    const { course, driver } = req.body;
    const { id } = req.params;
    const location = await Location.findOne({ driver: driver });
    if (!mongoose.isValidObjectId(id))
      return res.status(400).send("Mauvais format de l'ID ");
    const result = await Course.findOne({ _id: course });
    if (!result) return res.status(400).send("Commande non trouver");
    await result.updateOne({
      $set: {
        location: location,
        status: "Valider",
      },
    });
    const response = await Location.findOne({ driver: driver });
    const user = await Users.findById(driver);
    if (!response) return res.status(400).send("Location non trouver");
    await response.updateOne({
      $set: {
        isDisponible: false,
      },
    });
    await user.updateOne({
      $set: {
        status: "Indisponible",
      },
    });

    res.status(200).send("Terminer");
    return;
  }
);

module.exports = Router;
