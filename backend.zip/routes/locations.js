const Router = require("express").Router();
const mongoose = require("mongoose");
const Location = require("../model/LocationModel");
const Cars = require("../model/CarsModel");
const authentification = require("../auth/authentification");
const authorization = require("../auth/authorization");
const Users = require("../model/UserModel");

//ajouter une nouvelle location
Router.post("/new", [authentification, authorization], async (req, res) => {
  const { driver, car, time, tarif } = req.body;
  const location = new Location({
    driver,
    car,
    time,
    tarif,
  });
  const response = await Cars.findOne({ _id: car });
  const user = await Users.findOne({ _id: driver });
  await user.updateOne({
    $set: {
      status: "Disponible",
    },
  });
  //modifier le status de disponibiliter de la voiture
  if (!response) return res.status(400).send("Voiture non trouver");
  await response.updateOne({
    $set: {
      status: "Louer",
    },
  });
  await (await location.save()).populate("driver car");
  return res.send(location);
});

//retourner la voiture louer
Router.put("/return", [authentification, authorization], async (req, res) => {
  const { car_id, location_id } = req.body;
  const car = await Cars.findOne({ _id: car_id });
  const location = await Location.findOne({ _id: location_id }).populate(
    "driver"
  );
  const user = await Users.findOne({ _id: location.driver._id });
  await user.updateOne({
    $set: {
      status: "Disponible",
    },
  });
  if (!car) return res.status(400).send("Voiture non trouver");
  await location.updateOne({
    $set: {
      isDisponible: false,
    },
  });
  await car.updateOne({
    $set: {
      status: "Disponible",
    },
  });
  await location.save();
  return res.send("Mise a jours");
});

//prendre tous les locations disponible
Router.get("/list/me", [authentification], async (req, res) => {
  const { user } = req;
  const locations = await Location.find({ driver: user._id }).populate(
    "car driver"
  );
  res.status(200).send(locations);
  return;
});

//prendre tous les locations disponible
Router.get(
  "/list/disponible",
  [authentification, authorization],
  async (req, res) => {
    const locations = await Location.find({ isDisponible: true }).populate(
      "car driver"
    );
    if (locations.length > 0) {
      data = locations;
    } else {
      data = [];
    }
    res.status(200).send(data);
    return;
  }
);

module.exports = Router;
