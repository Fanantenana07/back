const Router = require("express").Router();
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const Users = require("../model/UserModel");
const Record = require("../model/RecordModel");
const authentification = require("../auth/authentification");

Router.post("/Register", async (req, res) => {
  const { nom, prenom, adresse, email, phone, password, title } = req.body;
  let photo, user;

  //hashage du mot de passe
  const salt = await bcrypt.genSalt(10);
  const hashPass = await bcrypt.hash(password, salt);
  const response = await Users.findOne({ email: email });
  if (!response) {
    //verification de l'existance du fichier a uploader
    if (req.files) {
      let path;
      title === "Client"
        ? (path = `${__dirname.slice(
            0,
            __dirname.length - 7
          )}/assets/users/clients/`)
        : (path = `${__dirname.slice(
            0,
            __dirname.length - 7
          )}/assets/users/chauffeur/profil/`);
      photo = req.files.photo.name;
      const file = req.files.photo;
      //copie du fichier sur server
      file.mv(`${path}${photo}`, (error) => {
        if (error)
          return res.status(500).send("impossible de telecharger la photo");
      });
    } else {
      photo = "avatar_placeholder.png";
    }

    if (title === "Chauffeur") {
      const status = "En validation";
      user = new Users({
        nom,
        password: hashPass,
        prenom,
        adresse,
        email,
        phone,
        photo,
        title,
        status,
      });
    } else {
      user = new Users({
        nom,
        password: hashPass,
        prenom,
        adresse,
        email,
        phone,
        photo,
        title,
      });
    }
    const response = await user.save();
    const token = response.genrateToken();
    res.status(200).send(token);
    return;
  } else {
    res.status(400).send("Un compte est deja associer a cet email");
    return;
  }
});

Router.post("/update", [authentification], async (req, res) => {
  const { nom, prenom, adresse, email, phone, password, title } = req.body;
  const { user } = req;
  let photo;
  //hashage du mot de passe
  const salt = await bcrypt.genSalt(10);
  const hashPass = await bcrypt.hash(password, salt);
  const result = await Users.findOne({ _id: user._id });
  if (result) {
    //verification de l'existance du fichier a uploader
    if (req.files) {
      let path = `${__dirname.slice(
        0,
        __dirname.length - 7
      )}/assets/users/clients/`;
      photo = req.files.photo.name;
      const file = req.files.photo;
      //copie du fichier sur server
      file.mv(`${path}${photo}`, (error) => {
        if (error)
          return res.status(500).send("impossible de telecharger la photo");
      });
    } else {
      photo = "avatar_placeholder.png";
    }
    await result.updateOne({
      $set: {
        nom,
        password: hashPass,
        prenom,
        adresse,
        email,
        phone,
        photo,
        title,
      },
    });
    res.status(200).send("Modification effectuer.");
    return;
  } else {
    res.status(400).send("Compte non trouver");
    return;
  }
});

Router.post("/Login", async (req, res) => {
  const { email, password } = req.body;
  const result = await Users.findOne({ email: email });
  if (!result) return res.status(400).send("L'utilisateur n'existe pas"); //verification de l'existance de l'utilisateur
  const isVali = await bcrypt.compare(password, result.password);
  if (!isVali) return res.status(400).send("Mot de passe incorrect"); //verification du mot de passe
  const token = result.genrateToken(); // generation du token
  res
    .status(200)
    .header("x-auth-token", token)
    .header("access-control-expose-headers", "x-auth-token")
    .send(token); //envoi du token
});

module.exports = Router;
