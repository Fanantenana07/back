const Router = require("express").Router();
const mongoose = require("mongoose");
const authentification = require("../auth/authentification");
const authorization = require("../auth/authorization");
const Car = require("../model/CarsModel");

//ajout des nouvelles voitures
Router.post("/new", [authentification, authorization], async (req, res) => {
  const { mark, plate, tranche, amount } = req.body;
  let images = [];
  const path = `${__dirname.slice(0, __dirname.length - 7)}/assets/cars/`;
  if (req.files) {
    //copie des fichiers sur server
    if (req.files.images.length) {
      req.files.images.forEach((file) => {
        images.push(file.name);
        file.mv(`${path}${file.name}`, (error) => {
          if (error)
            return res.status(500).send("impossible de telecharger la photo");
        });
      });
    } else {
      images.push(req.files.images.name);
      req.files.images.mv(`${path}${req.files.images.name}`, (error) => {
        if (error)
          return res.status(500).send("impossible de telecharger la photo");
      });
    }
  }
  const car = new Car({
    mark,
    plate,
    tranche,
    amount,
    images,
  });
  const reponse = await car.save();
  res.status(200).send(reponse);
  return;
});

//
Router.put(
  "/update/:id",
  [authentification, authorization],
  async (req, res) => {
    const { mark, plate, start, finish, amount } = req.body;
    const { id } = req.params;

    const path = `${__dirname.slice(0, __dirname.length - 7)}/assets/cars/`;
    if (req.files) {
      let images = [];
      //copie des fichiers sur server
      if (req.files.images.length) {
        req.files.images.forEach((file) => {
          images.push(file.name);
          file.mv(`${path}${file.name}`, (error) => {
            if (error)
              return res.status(500).send("impossible de telecharger la photo");
          });
        });
      } else {
        images.push(req.files.images.name);
        req.files.images.mv(`${path}${req.files.images.name}`, (error) => {
          if (error)
            return res.status(500).send("impossible de telecharger la photo");
        });
      }
    }
    const car = await Car.findOne({ _id: id });
    await car.updateOne({
      $set: {
        mark,
        plate,
        tranche,
        amount,
        images,
      },
    });
    res.status(200).send("Modification terminer");
    return;
  }
);

Router.put(
  "/update/status/:id",
  [authentification, authorization],
  async (req, res) => {
    const { status } = req.body;
    const { id } = req.params;
    const car = await Car.findOne({ _id: id });
    await car.updateOne({
      $set: {
        status,
      },
    });
    res.status(200).send("Modification terminer");
    return;
  }
);

Router.delete(
  "/delete/:id",
  [authentification, authorization],
  async (req, res) => {
    const { id } = req.params;
    const car = await Car.findOne({ _id: id });
    if (!car) res.status(400).send("Car not found");
    await car.deleteOne();
    res.status(200).send("suppression terminer");
    return;
  }
);

Router.get("/list",[authentification,authorization], async (req, res) => {
  const cars = await Car.find();
  res.send(cars);
});

Router.get("/list/disponible",[authentification,authorization], async (req, res) => {
  const cars = await Car.find({ status: "Disponible" });
  res.send(cars);
});

module.exports = Router;
