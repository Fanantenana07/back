const Router = require("express").Router();
const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const Users = require("../model/UserModel");
const Record = require("../model/RecordModel");
const authentification = require("../auth/authentification");

Router.get("/img/chauffeur/profil/:file", async (req, res) => {
  const file = req.params.file;
  res.sendFile(
    __dirname.slice(0, __dirname.length - 7) +
      `/assets/users/chauffeur/profil/` +
      file
  );
});
Router.get("/img/chauffeur/CIN/:file", async (req, res) => {
  const file = req.params.file;
  res.sendFile(
    __dirname.slice(0, __dirname.length - 7) +
      `/assets/users/chauffeur/cin/` +
      file
  );
});

Router.get("/img/chauffeur/casier/:file", async (req, res) => {
  const file = req.params.file;
  res.sendFile(
    __dirname.slice(0, __dirname.length - 7) +
      `/assets/users/chauffeur/casier/` +
      file
  );
});
Router.get("/img/chauffeur/permis/:file", async (req, res) => {
  const file = req.params.file;
  res.sendFile(
    __dirname.slice(0, __dirname.length - 7) +
      `/assets/users/chauffeur/permis/` +
      file
  );
});

module.exports = Router;
