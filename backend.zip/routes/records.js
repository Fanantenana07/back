const Router = require("express").Router();
const mongoose = require("mongoose");
const Record = require("../model/RecordModel");
const Users = require("../model/UserModel");
const authentification = require("../auth/authentification");
const authorization = require("../auth/authorization");
//assignation des dossier pour un chauffeur
Router.post("/assing", [authentification], async (req, res) => {
  const { age, numCIN, commentaires } = req.body;
  let CIN, casier, permis;
  const driver = req.user._id;
  const user = Users.findOne({ _id: driver });
  const response = await Record.findOne({ numCIN });
  //ajout des images complementaire au dossier
  if (user) {
    if (!response) {
      if (req.files) {
        if (req.files.CIN && req.files.permis && req.files.casier) {
          const path = `${__dirname.slice(
            0,
            __dirname.length - 7
          )}/assets/users/`;
          CIN = req.files.CIN;
          permis = req.files.permis;
          casier = req.files.casier;
          CIN.mv(`${path}chauffeur/casier/${casier.name}`, (error) => {
            if (error)
              return res.status(500).send("impossible de telecharger la photo");
          });
          permis.mv(`${path}chauffeur/cin/${CIN.name}`, (error) => {
            if (error)
              return res.status(500).send("impossible de telecharger la photo");
          });
          casier.mv(`${path}chauffeur/permis/${permis.name}`, (error) => {
            if (error)
              return res.status(500).send("impossible de telecharger la photo");
          });
        }
      }
      //enregisterement du dossier
      const record = new Record({
        user: driver,
        CIN: CIN.name,
        casier: casier.name,
        permis: permis.name,
        age,
        numCIN,
        commentaires,
      });
      user.updateOne({
        $set: {
          status: "Disponible",
        },
      });
      await record.save();
      res.status(200).send("Dossier ajouter.");
      return;
    } else {
      res.status(400).send("Votre dossier a deja ete pris en charge");
      return;
    }
  } else {
    res.status(400).send("Veuillez vous enregistrer d'abord");
    return;
  }
});

// modification de l'etat du dossier
Router.put(
  "/status/:id",
  [authentification, authorization],
  async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    if (!mongoose.isValidObjectId(id))
      return res.status(400).send("Mauvais format de l'ID ");
    const record = await Record.findOne({ _id: id }).populate("user");
    if (!record) return res.status(400).send("dossier non trouver");
    const response = await record.updateOne({
      $set: {
        status,
      },
    });

    const user = await Users.findOne({ _id: record.user._id.toString() });
    console.log(user);
    await user.updateOne({
      $set: {
        status: "Disponible",
      },
    });
    res.status(200).send(response);
    await record.save();
    return;
  }
);

// liste des chauffeurs en cours de validation
Router.get(
  "/list/progress",
  [authentification, authorization],
  async (req, res) => {
    const records = await Record.find({
      status: "En cours",
    }).populate("user");
    return res.status(200).send(records);
  }
);

//liste des chauffeurs valider
Router.get(
  "/list/valider",
  [authentification, authorization],
  async (req, res) => {
    const driver = await Users.find({ status: "Disponible" });
    return res.status(200).send(driver);
  }
);

Router.get("/me", [authentification], async (req, res) => {
  const { user } = req;
  const record = await Record.find({
    user: user._id,
  }).populate("user");
  console.log(record);
  return res.status(200).send(record);
});

//listes des chauffeurs valide
Router.get("/list/driver", async (req, res) => {
  const records = await Record.find({ status: "valide" }).populate("user");
  return res.status(200).send(records);
});
module.exports = Router;
