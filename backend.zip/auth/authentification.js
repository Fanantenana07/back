const jwt = require("jsonwebtoken");
const config = require("../config/secretKey.json");
function authentification(req, res, next) {
  const token = req.header("x-auth-token");
  if (!token) return res.send("PLease log first.");
  try {
    const user = jwt.verify(token, config.jwtToken);
    req.user = user;
    next();
  } catch (e) {
    return res.status(403).send("Authentifiaction non reconnue.");
  }
}

module.exports = authentification;
