const jwt = require("jsonwebtoken");
const config = require("../config/secretKey.json");
function authorization(req, res, next) {
  const { title } = req.user;
  if (title !== "Admin") return res.status(403).send("Operation not allow");
  next();
}

module.exports = authorization;
