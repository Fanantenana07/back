const mongoose = require("mongoose");
const carsSchema = mongoose.Schema({
  mark: {
    type: String,
    required: true,
  },
  plate: {
    type: String,
    required: true,
  },
  tranche: {
    type: String,
    required: true,
  }, //horaire de disponibilite

  status: {
    type: String,
    default: "Disponible", //disponible,en reparation,louer
  },
  amount: {
    type: Number,
    default: 1000,
  },
  images: {
    type: [String],
    required: true,
  },
});
const Race = mongoose.model("cars", carsSchema);
module.exports = Race;
