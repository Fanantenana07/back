const mongoose = require("mongoose");

//creation d'un schema d'un dossier
const recordSchema = mongoose.Schema({
  user: {
    type: mongoose.Types.ObjectId,
    ref: "users",
    required: true,
  },
  age: {
    type: Number,
    required: true,
  },
  numCIN: {
    type: String,
    required: true,
  },
  CIN: {
    type: String,
    required: true,
  },
  permis: {
    type: String,
    required: true,
  },
  casier: {
    type: String,
    required: true,
  },
  commentaires: {
    type: String,
  },
  status: {
    type: String,
    default: "En cours", //valide,refuser
  },
});
const Record = mongoose.model("records", recordSchema);
module.exports = Record;
