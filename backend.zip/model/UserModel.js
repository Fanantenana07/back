const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const config = require("../config/secretKey.json");

// schema pour utilisateur (Client ou Chauffeur)
const userSchema = mongoose.Schema({
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  nom: {
    type: String,
    required: true,
  },
  prenom: {
    type: String,
    required: true,
  },
  adresse: {
    type: String,
    required: true,
  },
  photo: {
    type: String,
    default: "avatar.png",
  },
  phone: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    default: "Client",
  },
  status: {
    type: String, //si chauffeur alors soit en validation,disponible,indisponible
  },
});

//creation d'une methode de genereation de token
userSchema.methods.genrateToken = function () {
  const token = jwt.sign(
    {
      _id: this._id,
      nom: this.nom,
      title: this.title,
      email: this.email,
      adresse: this.adresse,
      phone: this.phone,
      photo: this.photo,
      prenom: this.prenom,
    },
    config.jwtToken
  );
  return token;
};

//Creation de modele mongodb
const Users = mongoose.model("users", userSchema);
module.exports = Users;
