const mongoose = require("mongoose");

const raceSchema = mongoose.Schema({
  client: {
    type: mongoose.Types.ObjectId,
    ref: "users",
    required: true,
  },
  location: {
    type: mongoose.Types.ObjectId,
    ref: "locations",
  },
  starting: {
    type: String,
    required: true,
  },
  arrive: {
    type: String,
    required: true,
  },
  status: {
    type: String,
    default: "En cours", //en cours,valider,terminer
  },
  date: {
    type: String,
    default: Date(Date.now()).toString().slice(0, 24), //date de la course
  },
  distance: {
    type: String,
    required: true,
  },
  price: {
    type: Number,
    required: true,
  },
});
const Race = mongoose.model("race", raceSchema);
module.exports = Race;
