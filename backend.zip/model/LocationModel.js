const mongoose = require("mongoose");

//creation d'un schema d'un dossier
const locationSchema = mongoose.Schema({
  driver: {
    type: mongoose.Types.ObjectId,
    ref: "users",
    required: true,
  },
  car: {
    type: mongoose.Types.ObjectId,
    ref: "cars",
    required: true,
  },
  time: {
    type: String,
    required: true,
  },
  isDisponible: {
    type: Boolean,
    default: true,
  },
  tarif: {
    type: Number,
    default: 1000,
  }, //tarif du chauffeur
  date: {
    type: String,
    default: new Date(Date.now()).toString().slice(0, 24),
  },
});
const Location = mongoose.model("locations", locationSchema);

module.exports = Location;
